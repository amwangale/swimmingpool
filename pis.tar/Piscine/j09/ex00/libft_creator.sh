gcc -c *.c
ar rc libft.a *.o
ar s libft.a
rm *.o
