ldapwhoami -Q | cut -c 4-
